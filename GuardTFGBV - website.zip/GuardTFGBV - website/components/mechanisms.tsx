"use client"

export function Mechanisms() {
  return (
    <section id="learn" className="relative py-16 md:py-24 px-4 bg-background border-t border-border">
      <div className="container max-w-5xl mx-auto">
        <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-sentient text-foreground mb-12 md:mb-16">
          Defending <span className="text-primary">Mechanisms</span>
        </h2>

        <div className="space-y-8 md:space-y-12">
          {[
            {
              title: "Prevention",
              items: [
                "Use strong, unique passwords",
                "Enable two-factor authentication",
                "Review privacy settings regularly",
                "Be cautious about what you share",
              ],
            },
            {
              title: "Protection",
              items: [
                "Block and report harmful accounts",
                "Document incidents with screenshots",
                "Use privacy controls on social media",
                "Install antivirus software",
              ],
            },
            {
              title: "Support",
              items: [
                "Talk to someone you trust",
                "Contact local law enforcement if threatened",
                "Seek professional counseling",
                "Join support groups",
              ],
            },
          ].map((section, idx) => (
            <div key={idx} className="space-y-3 md:space-y-4">
              <h3 className="text-xl md:text-2xl font-sentient text-foreground">{section.title}</h3>
              <div className="space-y-2 pl-3 md:pl-4">
                {section.items.map((item) => (
                  <p key={item} className="font-mono text-xs sm:text-sm text-foreground/60">
                    • {item}
                  </p>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
