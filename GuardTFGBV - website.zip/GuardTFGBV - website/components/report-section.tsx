"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Textarea } from "./ui/textarea"
import { Label } from "./ui/label"

export function ReportSection() {
  const [formData, setFormData] = useState({
    fullName: "",
    description: "",
    link: "",
  })
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.description.trim() || !formData.link.trim()) {
      alert("Please fill in all required fields (Description and Link)")
      return
    }

    setLoading(true)

    try {
      const response = await fetch("/api/report", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        setSubmitted(true)
        setFormData({ fullName: "", description: "", link: "" })
        setTimeout(() => setSubmitted(false), 5000)
      } else {
        alert("Failed to submit report. Please try again.")
      }
    } catch (error) {
      alert("An error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <section id="report" className="relative py-16 md:py-24 px-4 bg-background border-t border-border">
      <div className="container max-w-3xl mx-auto">
        <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-sentient text-foreground mb-8 md:mb-12">
          Report an <span className="text-primary">Incident</span>
        </h2>

        {submitted && (
          <div className="mb-6 md:mb-8 p-3 md:p-4 bg-primary/10 border border-primary/30 rounded-lg">
            <p className="text-foreground font-mono text-xs md:text-sm">✓ Thank you for your report.</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5 md:space-y-6">
          <div className="space-y-2">
            <Label htmlFor="fullName" className="text-foreground/90 font-mono text-xs md:text-sm">
              Full Name <span className="text-foreground/40">(Optional)</span>
            </Label>
            <Input
              id="fullName"
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              placeholder="Your name"
              className="bg-background border-border text-foreground text-sm md:text-base"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-foreground/90 font-mono text-xs md:text-sm">
              Description <span className="text-primary font-bold">*</span>
            </Label>
            <Textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              placeholder="Describe the incident..."
              rows={4}
              className="bg-background border-border text-foreground resize-none text-sm md:text-base"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="link" className="text-foreground/90 font-mono text-xs md:text-sm">
              Link/Evidence <span className="text-primary font-bold">*</span>
            </Label>
            <Input
              id="link"
              name="link"
              type="url"
              value={formData.link}
              onChange={handleChange}
              placeholder="https://..."
              className="bg-background border-border text-foreground text-sm md:text-base"
              required
            />
          </div>

          <Button type="submit" className="w-full text-sm md:text-base text-white" disabled={loading}>
            {loading ? "[Submitting...]" : "[Submit Report]"}
          </Button>
        </form>
      </div>
    </section>
  )
}
