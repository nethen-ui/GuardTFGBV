"use client"

import Link from "next/link"
import { MobileMenu } from "./mobile-menu"
import { usePathname } from "next/navigation"

export const Header = () => {
  const pathname = usePathname()
  const isHomePage = pathname === "/"

  return (
    <div className="fixed z-50 pt-4 md:pt-6 lg:pt-8 top-0 left-0 w-full px-3 md:px-4">
      <div className="max-w-7xl mx-auto rounded-full backdrop-blur-md bg-white/10 dark:bg-black/10 border border-white/20 dark:border-white/10 px-4 md:px-6 py-3 md:py-4 flex items-center justify-between shadow-lg">
        <Link
          href="/"
          className="text-lg md:text-xl lg:text-2xl font-sentient font-bold text-foreground hover:text-foreground/80 duration-150 transition-colors ease-out"
        >
          GuardTFGBV
        </Link>
        <nav className="flex max-lg:hidden items-center justify-center gap-x-4 lg:gap-x-8">
          {["About", "Learn", "Report", "Resources"].map((item) => (
            <Link
              className="uppercase text-xs lg:text-sm font-mono text-foreground/60 hover:text-foreground/100 duration-150 transition-colors ease-out"
              href={`/#${item.toLowerCase()}`}
              key={item}
            >
              {item}
            </Link>
          ))}
          <Link
            className="uppercase text-xs lg:text-sm font-mono text-foreground/60 hover:text-foreground/100 duration-150 transition-colors ease-out"
            href="/simulator"
          >
            Simulator
          </Link>
        </nav>
        <div className="flex items-center gap-x-2 lg:gap-x-4">
          {isHomePage && (
            <Link
              className="uppercase max-lg:hidden text-xs lg:text-sm transition-colors ease-out duration-150 font-mono text-primary hover:text-primary/80 whitespace-nowrap"
              href=""
              onClick={(e) => e.preventDefault()}
              title="Download Extension coming soon"
            >
              [Download Extension]
            </Link>
          )}
          <MobileMenu />
        </div>
      </div>
    </div>
  )
}
