"use client"

export function Definition() {
  return (
    <section id="about" className="relative py-16 md:py-24 px-4 bg-background">
      <div className="container max-w-6xl mx-auto">
        <div className="space-y-12 md:space-y-16">
          <div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-sentient text-foreground mb-6">
              Understanding <span className="text-primary">TFGBV</span>
            </h2>
            <p className="font-mono text-base md:text-lg text-foreground/80 max-w-3xl leading-relaxed">
              Technology Facilitated Gender-Based Violence (TFGBV) happens when digital tools become weapons. It's the
              use of technology—like social media, messaging apps, or tracking software—to threaten, harass, control, or
              harm someone based on their gender. This violence can be just as damaging as physical abuse, leaving
              lasting psychological scars.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 md:gap-8">
            {[
              {
                title: "Cyberstalking & Harassment",
                desc: "Persistent unwanted messages, monitoring your online activity, or sending threatening content that makes you feel unsafe in your digital spaces.",
                examples: [
                  "Constant messaging despite being blocked",
                  "Tracking your location without consent",
                  "Creating fake profiles to monitor you",
                ],
              },
              {
                title: "Image-Based Abuse",
                desc: "Sharing intimate images or videos without your permission, creating fake explicit content (deepfakes), or threatening to expose private media.",
                examples: ["Revenge porn distribution", "Deepfake creation", "Threatening to share private photos"],
              },
              {
                title: "Doxxing & Exposure",
                desc: "Publishing your personal information online—like your address, phone number, or workplace—to intimidate, harass, or put you in danger.",
                examples: [
                  "Sharing home address publicly",
                  "Posting workplace information",
                  "Exposing private details for harassment",
                ],
              },
              {
                title: "Sextortion & Coercion",
                desc: "Using intimate images or information to blackmail you into providing more content, money, or complying with demands. This is a serious crime.",
                examples: [
                  "Demanding money to not share images",
                  "Forcing someone to send more content",
                  "Threatening exposure for compliance",
                ],
              },
              {
                title: "Digital Control & Monitoring",
                desc: "Installing spyware, demanding passwords, constant location tracking, or controlling who you talk to online. This is about power and control.",
                examples: [
                  "Installing tracking apps without consent",
                  "Demanding all social media passwords",
                  "Monitoring every online interaction",
                ],
              },
              {
                title: "Online Impersonation",
                desc: "Creating fake accounts pretending to be you, posting harmful content in your name, or damaging your reputation through false identities.",
                examples: [
                  "Fake profiles using your photos",
                  "Posting harmful content as you",
                  "Sending messages pretending to be you",
                ],
              },
            ].map((type, idx) => (
              <div
                key={idx}
                className="bg-white/5 dark:bg-black/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:border-primary/30 transition-all"
              >
                <h3 className="text-lg md:text-xl font-sentient text-primary mb-3">{type.title}</h3>
                <p className="font-mono text-xs md:text-sm text-foreground/70 mb-4 leading-relaxed">{type.desc}</p>
                <div className="space-y-2">
                  {type.examples.map((example, i) => (
                    <div key={i} className="flex items-start gap-2 text-foreground/60">
                      <span className="text-primary flex-shrink-0 mt-1">•</span>
                      <span className="font-mono text-xs">{example}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="bg-primary/10 border border-primary/20 rounded-2xl p-6 md:p-8">
            <p className="font-mono text-sm md:text-base text-foreground leading-relaxed">
              <strong className="text-primary">Remember:</strong> TFGBV is never your fault. Whether it's an ex-partner,
              someone you met online, or even a stranger, no one has the right to use technology to hurt, control, or
              intimidate you. You deserve to feel safe both offline and online. If you're experiencing TFGBV, you're not
              alone—there is help available.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
