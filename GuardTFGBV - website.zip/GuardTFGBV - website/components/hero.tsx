"use client"

import Link from "next/link"
import { GL } from "./gl"
import { Pill } from "./pill"
import { Button } from "./ui/button"
import { useState } from "react"

export function Hero() {
  const [hovering, setHovering] = useState(false)
  return (
    <div className="flex flex-col min-h-[100svh] justify-between">
      <GL hovering={hovering} />

      <div className="pb-12 md:pb-16 mt-auto text-center relative z-10 px-4">
        <Pill className="mb-4 md:mb-6">TFGBV AWARENESS</Pill>
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-sentient">
          Guard Against <br />
          <i className="font-light">Digital Gender</i> Violence
        </h1>
        <p className="font-mono text-xs sm:text-sm md:text-base text-foreground/60 text-balance mt-6 md:mt-8 max-w-[520px] mx-auto px-4">
          Technology Facilitated Gender-Based Violence (TFGBV) awareness and support platform. Learn, report, and
          defend.
        </p>

        <div className="flex gap-3 md:gap-4 justify-center items-center mt-10 md:mt-14 flex-wrap px-4">
          <Link className="contents" href="/#report">
            <Button
              onMouseEnter={() => setHovering(true)}
              onMouseLeave={() => setHovering(false)}
              className="text-xs sm:text-sm md:text-base text-white"
            >
              [Report Incident]
            </Button>
          </Link>

          <Link className="contents" href="/chat">
            <Button
              onMouseEnter={() => setHovering(true)}
              onMouseLeave={() => setHovering(false)}
              className="text-xs sm:text-sm md:text-base text-white"
            >
              [Guard AI]
            </Button>
          </Link>

          <Link className="contents" href="/simulator">
            <Button
              onMouseEnter={() => setHovering(true)}
              onMouseLeave={() => setHovering(false)}
              variant="outline"
              className="text-xs sm:text-sm md:text-base bg-transparent"
            >
              [Try Simulator]
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
