"use client"

export function VideoSection() {
  return (
    <section id="resources" className="relative py-16 md:py-24 px-4 bg-background">
      <div className="container max-w-4xl mx-auto">
        <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-sentient text-foreground mb-8 md:mb-12">
          Educational <span className="text-primary">Resources</span>
        </h2>

        <div className="aspect-video rounded-lg overflow-hidden border border-border mb-6 md:mb-8">
          <iframe
            width="100%"
            height="100%"
            src="https://www.youtube.com/embed/XK0WAu1EybM"
            title="TFGBV Awareness Video"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>

        <p className="font-mono text-xs sm:text-sm text-foreground/60">
          Learn more about technology-facilitated gender-based violence and how you can help combat it.
        </p>
      </div>
    </section>
  )
}
