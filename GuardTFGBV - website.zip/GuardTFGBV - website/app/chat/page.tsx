"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { GL } from "@/components/gl"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { ArrowLeft, Send, Settings } from "lucide-react"

interface Message {
  role: "user" | "assistant"
  content: string
}

export default function ChatPage() {
  const [apiKey, setApiKey] = useState("")
  const [showSettings, setShowSettings] = useState(false)
  const [apiKeyInput, setApiKeyInput] = useState("")
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const storedKey = localStorage.getItem("guardtfgbv_chatbot_api_key")
    if (storedKey) {
      setApiKey(storedKey)
      setMessages([
        {
          role: "assistant",
          content:
            "Hello! I'm Guard AI, your assistant for Technology-Facilitated Gender-Based Violence (TFGBV) awareness and support. How can I help you today?",
        },
      ])
    } else {
      setShowSettings(true)
    }
  }, [])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSaveApiKey = () => {
    if (!apiKeyInput.trim()) {
      alert("Please enter a valid API key")
      return
    }
    localStorage.setItem("guardtfgbv_chatbot_api_key", apiKeyInput)
    setApiKey(apiKeyInput)
    setShowSettings(false)
    setMessages([
      {
        role: "assistant",
        content:
          "Hello! I'm Guard AI, your assistant for Technology-Facilitated Gender-Based Violence (TFGBV) awareness and support. How can I help you today?",
      },
    ])
  }

  const formatResponse = (text: string) => {
    return text
      .replace(/\*\*(.*?)\*\*/g, '<strong class="text-primary">$1</strong>')
      .replace(/^### (.*$)/gim, '<h4 class="text-base font-semibold text-primary mt-3 mb-2">$1</h4>')
      .replace(/^- (.*$)/gim, '<li class="ml-4 mb-1">$1</li>')
      .replace(/(<li>.*<\/li>\s*)+/gs, (match) => `<ul class="list-disc space-y-1 my-2">${match}</ul>`)
      .replace(/\n\n/g, "<br><br>")
      .replace(/\n/g, "<br>")
  }

  const handleSend = async () => {
    if (!input.trim() || loading) return

    const userMessage: Message = { role: "user", content: input }
    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setLoading(true)

    try {
      const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "llama-3.3-70b-versatile",
          messages: [
            {
              role: "system",
              content:
                "You are Guard AI, a helpful assistant specialized in Technology Facilitated Gender-Based Violence (TFGBV) awareness. You help users understand TFGBV, stay safe online, and know how to report incidents. Be empathetic, informative, and supportive. Format your responses with clear structure using **bold** for key terms and organize information with bullet points (use - for list items) and headings (use ### for headings) for easy reading.",
            },
            ...messages,
            userMessage,
          ],
          temperature: 0.3,
          max_tokens: 1500,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        const assistantMessage: Message = { role: "assistant", content: data.choices[0].message.content }
        setMessages((prev) => [...prev, assistantMessage])
      } else {
        setMessages((prev) => [
          ...prev,
          { role: "assistant", content: "Sorry, I encountered an error. Please check your API key and try again." },
        ])
      }
    } catch (error) {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "Sorry, I encountered an error. Please try again." },
      ])
    } finally {
      setLoading(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  if (showSettings || !apiKey) {
    return (
      <div className="h-screen flex flex-col overflow-hidden">
        <GL hovering={false} />

        <div className="fixed z-50 pt-4 md:pt-6 lg:pt-8 top-0 left-0 w-full px-3 md:px-4">
          <div className="max-w-4xl mx-auto rounded-full backdrop-blur-md bg-white/10 dark:bg-black/10 border border-white/20 dark:border-white/10 px-4 md:px-6 py-3 md:py-4 flex items-center justify-between shadow-lg">
            <Link
              href="/"
              className="flex items-center gap-2 text-foreground hover:text-foreground/80 transition-colors"
            >
              <ArrowLeft className="w-4 h-4 md:w-5 md:h-5" />
              <span className="text-xl md:text-2xl font-sentient font-bold">GuardTFGBV</span>
            </Link>
            <span className="text-xs md:text-sm font-mono text-foreground/60">Guard AI Setup</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto pt-24 md:pt-32 pb-6 md:pb-8 px-3 md:px-4 relative z-10 flex items-center justify-center">
          <div className="max-w-md mx-auto w-full">
            <div className="backdrop-blur-md bg-white/10 dark:bg-black/10 border border-white/20 dark:border-white/10 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
              <h2 className="text-2xl md:text-3xl font-sentient text-foreground text-center">Setup Required</h2>
              <p className="text-sm font-mono text-foreground/70 text-center">
                Enter your Groq API key to use Guard AI chatbot features.
              </p>
              <Input
                type="password"
                placeholder="Enter Groq API Key"
                value={apiKeyInput}
                onChange={(e) => setApiKeyInput(e.target.value)}
                className="bg-white/5 border-white/10 text-foreground"
              />
              <Button onClick={handleSaveApiKey} className="w-full text-white" size="lg">
                Save API Key
              </Button>
              <a
                href="https://console.groq.com/keys"
                target="_blank"
                rel="noopener noreferrer"
                className="block text-center text-xs text-primary hover:text-primary/80 transition-colors"
              >
                Get API Key from Groq →
              </a>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <GL hovering={false} />

      <div className="fixed z-50 pt-4 md:pt-6 lg:pt-8 top-0 left-0 w-full px-3 md:px-4">
        <div className="max-w-4xl mx-auto rounded-full backdrop-blur-md bg-white/10 dark:bg-black/10 border border-white/20 dark:border-white/10 px-4 md:px-6 py-3 md:py-4 flex items-center justify-between shadow-lg">
          <Link href="/" className="flex items-center gap-2 text-foreground hover:text-foreground/80 transition-colors">
            <ArrowLeft className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-xl md:text-2xl font-sentient font-bold">GuardTFGBV</span>
          </Link>
          <div className="flex items-center gap-3">
            <span className="text-xs md:text-sm font-mono text-foreground/60">Guard AI</span>
            <button
              onClick={() => setShowSettings(true)}
              className="p-2 hover:bg-white/10 rounded-full transition-colors"
              title="Change API Key"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pt-24 md:pt-32 pb-6 md:pb-8 px-3 md:px-4 relative z-10">
        <div className="max-w-4xl mx-auto space-y-4 md:space-y-6">
          {messages.map((message, index) => (
            <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[85%] sm:max-w-[80%] p-3 md:p-4 rounded-2xl ${
                  message.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-white/10 dark:bg-black/10 backdrop-blur-md border border-white/20 dark:border-white/10 text-foreground"
                }`}
              >
                {message.role === "assistant" ? (
                  <div
                    className="text-xs sm:text-sm font-mono whitespace-pre-wrap break-words prose prose-invert max-w-none"
                    dangerouslySetInnerHTML={{ __html: formatResponse(message.content) }}
                  />
                ) : (
                  <p className="text-xs sm:text-sm font-mono whitespace-pre-wrap break-words">{message.content}</p>
                )}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="max-w-[85%] sm:max-w-[80%] p-3 md:p-4 rounded-2xl bg-white/10 dark:bg-black/10 backdrop-blur-md border border-white/20 dark:border-white/10">
                <p className="text-xs sm:text-sm font-mono text-foreground/60">Guard AI is typing...</p>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      <div className="relative z-10 px-3 md:px-4 pb-4 md:pb-6">
        <div className="max-w-4xl mx-auto">
          <div className="backdrop-blur-md bg-white/10 dark:bg-black/10 border border-white/20 dark:border-white/10 rounded-2xl p-3 md:p-4 shadow-lg">
            <div className="flex gap-2">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="Ask about TFGBV, safety tips, resources..."
                className="flex-1 bg-transparent border-0 focus:ring-0 resize-none text-foreground placeholder:text-foreground/40 text-sm md:text-base"
                rows={2}
                disabled={loading}
              />
              <Button
                onClick={handleSend}
                disabled={loading || !input.trim()}
                size="icon"
                className="shrink-0 h-auto aspect-square"
              >
                <Send className="w-3 h-3 md:w-4 md:h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
