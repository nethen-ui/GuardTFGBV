import { NextResponse } from "next/server"
import { API_CONFIG } from "@/config/api-keys"

export async function POST(req: Request) {
  try {
    const { messages } = await req.json()

    const apiKey = API_CONFIG.ML_API_TOKEN

    if (!apiKey) {
      return NextResponse.json({ error: "Groq API key not configured" }, { status: 500 })
    }

    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        messages: [
          {
            role: "system",
            content:
              "You are Guard AI, an expert assistant on Technology-Facilitated Gender-Based Violence (TFGBV). You provide information, support, and resources about digital safety, online harassment, cyberstalking, image-based abuse, and other forms of technology-facilitated gender-based violence. Be empathetic, informative, and always prioritize the safety and wellbeing of those seeking help.",
          },
          ...messages,
        ],
        temperature: 0.7,
        max_tokens: 1024,
      }),
    })

    if (!response.ok) {
      throw new Error("Failed to get response from Groq")
    }

    const data = await response.json()
    return NextResponse.json({ message: data.choices[0].message.content })
  } catch (error) {
    return NextResponse.json({ error: "Failed to process chat request" }, { status: 500 })
  }
}
