import { NextResponse } from "next/server"
import { API_CONFIG } from "@/config/api-keys"

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { fullName, description, link } = body

    const { MAIL_SVC_ID, MAIL_TPL_ID, MAIL_PRI_KEY } = API_CONFIG

    if (!description?.trim() || !link?.trim()) {
      return NextResponse.json(
        { error: "Description and Link are required" },
        { status: 400 }
      )
    }

    const emailResponse = await fetch(
      "https://api.emailjs.com/api/v1.0/email/send",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${MAIL_PRI_KEY}` 
        },
        body: JSON.stringify({
          service_id: MAIL_SVC_ID,
          template_id: MAIL_TPL_ID,
          template_params: {
            full_name: fullName || "Anonymous",
            description,
            link
          }
        })
      }
    )

    const text = await emailResponse.text()

    if (!emailResponse.ok) {
      return NextResponse.json(
        { error: "EmailJS failed", details: text },
        { status: 500 }
      )
    }

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error("SERVER ERROR:", err)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}

