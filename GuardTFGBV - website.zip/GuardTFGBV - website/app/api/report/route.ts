import { NextResponse } from "next/server"
import { API_CONFIG } from "@/config/api-keys"

export async function POST(req: Request) {
  try {
    const { fullName, description, link } = await req.json()

    const serviceId = API_CONFIG.MAIL_SVC_ID
    const templateId = API_CONFIG.MAIL_TPL_ID
    const publicKey = API_CONFIG.MAIL_PUB_KEY

    if (!serviceId || !templateId || !publicKey) {
      return NextResponse.json({ error: "EmailJS configuration missing" }, { status: 500 })
    }

    const emailData = {
      service_id: serviceId,
      template_id: templateId,
      user_id: publicKey,
      template_params: {
        from_name: fullName || "Anonymous",
        description: description,
        link: link,
        to_email: "your-email@example.com",
      },
    }

    const response = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(emailData),
    })

    if (!response.ok) {
      throw new Error("Failed to send email")
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: "Failed to process report" }, { status: 500 })
  }
}
