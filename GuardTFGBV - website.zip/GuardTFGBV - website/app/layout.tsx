import type React from "react"
import type { Metadata } from "next"
import "./globals.css"
import { Header } from "@/components/header"
import { ThemeProvider } from "@/components/theme-provider"

export const metadata: Metadata = {
  title: "GuardTFGBV - Technology Facilitated Gender-Based Violence Awareness",
  description: "Learn about TFGBV, defending mechanisms, and report incidents anonymously",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body suppressHydrationWarning>
        <ThemeProvider>
          <Header />
          {children}
          <footer className="relative z-10 border-t border-border bg-background py-6 px-4">
            <div className="container max-w-7xl mx-auto text-center">
              <p className="text-sm font-mono text-foreground/60">
                For support and inquiries: <span className="text-primary">+2519111111</span>
              </p>
            </div>
          </footer>
        </ThemeProvider>
      </body>
    </html>
  )
}
