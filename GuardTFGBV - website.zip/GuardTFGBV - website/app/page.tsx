"use client"

import { Hero } from "@/components/hero"
import { Definition } from "@/components/definition"
import { Mechanisms } from "@/components/mechanisms"
import { VideoSection } from "@/components/video-section"
import { ReportSection } from "@/components/report-section"
import { Leva } from "leva"

export default function Home() {
  return (
    <>
      <Hero />
      <Definition />
      <Mechanisms />
      <VideoSection />
      <ReportSection />
      <Leva hidden />
    </>
  )
}
