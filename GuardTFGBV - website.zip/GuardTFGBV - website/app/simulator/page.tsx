"use client"

import { useState, useEffect } from "react"
import { GL } from "@/components/gl"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

interface Scenario {
  id: number
  message: string
  options: string[]
  correctIndex: number
  explanation: string
  riskScore: number
}

const scenarios: Scenario[] = [
  {
    id: 1,
    message: "Hey, I noticed you posted a photo with your new coworker. Who is he? You two look pretty close...",
    options: [
      "Just a colleague, nothing to worry about!",
      "Why are you asking? Do you not trust me?",
      "I don't feel comfortable with you monitoring my posts like this.",
      "Let me delete it if it bothers you.",
    ],
    correctIndex: 2,
    explanation:
      "Monitoring and questioning your social media activity is a form of digital control. Setting clear boundaries is important.",
    riskScore: 65,
  },
  {
    id: 2,
    message: "Can you send me your location? I just want to make sure you're safe.",
    options: [
      "Sure, here it is!",
      "I'm fine, I'll text you when I'm home.",
      "I'd rather not share my location constantly.",
      "Why do you need to know where I am all the time?",
    ],
    correctIndex: 2,
    explanation: "Constant location tracking is a red flag for controlling behavior. You have the right to privacy.",
    riskScore: 70,
  },
  {
    id: 3,
    message: "I saw you were online but didn't reply to me for 2 hours. What were you doing?",
    options: [
      "Sorry, I was busy with work.",
      "I don't have to explain every moment of my day.",
      "I'll try to respond faster next time.",
      "My phone was in another room.",
    ],
    correctIndex: 1,
    explanation: "You're not obligated to be constantly available. Demanding immediate responses is a form of control.",
    riskScore: 55,
  },
  {
    id: 4,
    message: "If you really loved me, you'd share your phone password with me. I share mine with you.",
    options: [
      "Okay, it's 1234.",
      "I need my privacy, that doesn't mean I don't love you.",
      "Why don't you trust me?",
      "Fine, but you have to promise not to go through my messages.",
    ],
    correctIndex: 1,
    explanation:
      "Pressuring someone to share passwords under the guise of love is manipulation. Privacy is not a lack of trust.",
    riskScore: 75,
  },
  {
    id: 5,
    message: "I saved that photo you sent me. Don't worry, it's just for me. But you should send more...",
    options: [
      "I'm not comfortable with that.",
      "Okay, but promise you won't show anyone.",
      "Maybe later.",
      "Delete that photo please.",
    ],
    correctIndex: 0,
    explanation:
      "Requesting intimate images and implying they're being saved can lead to exploitation. Always trust your discomfort.",
    riskScore: 85,
  },
  {
    id: 6,
    message: "You changed your profile picture without telling me? I thought we agreed you'd ask first.",
    options: [
      "Sorry, I forgot to tell you.",
      "I didn't know I needed permission to change my own picture.",
      "You're right, I should have asked.",
      "It's just a picture, why does it matter?",
    ],
    correctIndex: 1,
    explanation: "No one should require permission to manage their own social media. This is controlling behavior.",
    riskScore: 60,
  },
  {
    id: 7,
    message: "I noticed you blocked me on Instagram. If you unblock me right now, I won't get mad. But if you don't...",
    options: [
      "I'll unblock you.",
      "That sounds like a threat. I'm not comfortable with this.",
      "I blocked you because I needed space.",
      "Sorry, I didn't mean to upset you.",
    ],
    correctIndex: 1,
    explanation: "Veiled threats and coercion are serious red flags. You have the right to block anyone without fear.",
    riskScore: 90,
  },
  {
    id: 8,
    message: "Everyone can see your posts. You should make your account private so only I can see what you share.",
    options: [
      "That's a good idea, I'll do that.",
      "I like having a public account.",
      "I'll think about it.",
      "Why do you want to control who sees my posts?",
    ],
    correctIndex: 3,
    explanation: "Isolating you digitally by limiting your online presence is a controlling tactic.",
    riskScore: 68,
  },
  {
    id: 9,
    message: "Send me a picture of what you're wearing tonight. I want to make sure it's appropriate.",
    options: [
      "Sure, here you go!",
      "I'm confident in my own choices.",
      "Do you not trust my judgment?",
      "I'd rather not, I'll see you later.",
    ],
    correctIndex: 1,
    explanation: "Policing what you wear is a form of control. You have autonomy over your appearance.",
    riskScore: 72,
  },
  {
    id: 10,
    message: "I created a shared cloud album for us. Upload all your photos there so I can see everything.",
    options: [
      "Okay, sounds fun!",
      "I prefer to keep some photos private.",
      "Why do you need to see all my photos?",
      "Maybe just some photos, not all.",
    ],
    correctIndex: 1,
    explanation: "Requesting access to all your digital content removes your privacy and autonomy.",
    riskScore: 66,
  },
  {
    id: 11,
    message: "I saw you liked someone's post. Who is that person? Why are you interacting with them?",
    options: [
      "Just a friend from school.",
      "I can like whoever's posts I want.",
      "Sorry, I won't like their posts anymore.",
      "It's nothing, don't worry.",
    ],
    correctIndex: 1,
    explanation: "Monitoring and questioning your online interactions is a form of digital surveillance and control.",
    riskScore: 63,
  },
  {
    id: 12,
    message: "If you don't respond in 10 minutes, I'm coming to your house. I need to know you're okay.",
    options: [
      "Okay, I'm here, everything is fine.",
      "That's not okay. I'll reach out when I can.",
      "Sorry for worrying you!",
      "Please don't show up unannounced.",
    ],
    correctIndex: 1,
    explanation: "Using concern as a pretext for control and showing up uninvited is threatening behavior.",
    riskScore: 88,
  },
  {
    id: 13,
    message: "I installed a tracking app on your phone for safety. You don't mind, right?",
    options: [
      "I guess it's fine if it's for safety.",
      "No, that's a violation of my privacy. Remove it.",
      "Why would you do that without asking?",
      "Okay, but only for emergencies.",
    ],
    correctIndex: 1,
    explanation: "Installing tracking software without consent is a serious violation and potentially illegal.",
    riskScore: 95,
  },
  {
    id: 14,
    message: "You haven't posted about us in a while. Are you embarrassed of me or something?",
    options: [
      "No, I'll post something soon.",
      "I don't feel the need to share everything online.",
      "Sorry, I didn't realize it mattered to you.",
      "You're right, I should post more about us.",
    ],
    correctIndex: 1,
    explanation:
      "Guilt-tripping someone into posting about the relationship is manipulative. Your online presence is yours to control.",
    riskScore: 58,
  },
  {
    id: 15,
    message:
      "I know your email password. I checked your inbox and saw you've been talking to your ex. We need to talk.",
    options: [
      "I can explain everything.",
      "You had no right to access my email without permission.",
      "I'm sorry, I should have told you.",
      "How did you get my password?",
    ],
    correctIndex: 1,
    explanation: "Accessing someone's accounts without permission is a violation of privacy and potentially illegal.",
    riskScore: 92,
  },
  {
    id: 16,
    message: "Turn on your camera so I can see you're really at home and not lying to me.",
    options: [
      "Okay, give me a second.",
      "I don't need to prove where I am. I told you I'm home.",
      "Why don't you believe me?",
      "Fine, but this is the last time.",
    ],
    correctIndex: 1,
    explanation: "Demanding video proof of your location is controlling and shows a lack of trust and respect.",
    riskScore: 78,
  },
  {
    id: 17,
    message:
      "I noticed you unfollowed me. If you don't follow me back, I'm going to post those screenshots of our private conversations.",
    options: [
      "I'll unblock you.",
      "That's blackmail. I'm reporting this.",
      "Please don't do that.",
      "Why would you threaten me like that?",
    ],
    correctIndex: 1,
    explanation: "Threatening to expose private information is a form of digital blackmail and abuse.",
    riskScore: 98,
  },
  {
    id: 18,
    message:
      "You took too long to reply. I guess you're not interested anymore. Maybe I should just share your number with others.",
    options: [
      "No, please don't. I was just busy.",
      "Threatening to share my personal information is not okay.",
      "I'm sorry for not replying faster.",
      "Why are you being like this?",
    ],
    correctIndex: 1,
    explanation: "Threatening to share personal information as punishment is a form of coercion and revenge tactics.",
    riskScore: 93,
  },
  {
    id: 19,
    message: "I saw you online but you didn't open my message for 30 minutes. I deserve an explanation.",
    options: [
      "Sorry, I was in a meeting.",
      "I don't owe you an explanation for every minute of my day.",
      "I'll try to be more responsive.",
      "My phone was on silent.",
    ],
    correctIndex: 1,
    explanation:
      "You have the right to respond on your own time. Demanding explanations for response times is controlling.",
    riskScore: 62,
  },
  {
    id: 20,
    message: "I think you should delete that friend from social media. They're clearly interested in you.",
    options: [
      "If it bothers you, I'll do it.",
      "That's my decision to make, not yours.",
      "Why are you so jealous?",
      "They're just a friend, nothing more.",
    ],
    correctIndex: 1,
    explanation: "Demanding you remove friends based on their insecurity is an attempt to isolate and control you.",
    riskScore: 71,
  },
  {
    id: 21,
    message: "Send me a screenshot of your recent DMs so I can see you're not hiding anything.",
    options: [
      "Sure, here they are.",
      "That's an invasion of my privacy. I won't do that.",
      "I have nothing to hide if that's what you think.",
      "Why don't you trust me?",
    ],
    correctIndex: 1,
    explanation: "Demanding access to private conversations violates your boundaries and privacy.",
    riskScore: 79,
  },
  {
    id: 22,
    message: "You liked that person's photo from 3 weeks ago. Were you stalking their profile?",
    options: [
      "No, it just showed up on my feed.",
      "You're going through my likes? That's concerning.",
      "I don't remember liking it.",
      "It doesn't mean anything.",
    ],
    correctIndex: 1,
    explanation:
      "Monitoring your social media activity to this degree is surveillance and a red flag for controlling behavior.",
    riskScore: 67,
  },
  {
    id: 23,
    message: "If you really care about me, you'd let me read through your messages to prove there's nothing going on.",
    options: [
      "Okay, if it makes you feel better.",
      "Trust isn't built by invading privacy. I won't do that.",
      "What do you think you'll find?",
      "I don't like this, but fine.",
    ],
    correctIndex: 1,
    explanation: "Using emotional manipulation to access private information is coercive and disrespectful.",
    riskScore: 76,
  },
  {
    id: 24,
    message: "I noticed you turned off your location sharing. Turn it back on or I'll assume you're hiding something.",
    options: [
      "Okay, I'll turn it back on.",
      "My location is my business. This is not okay.",
      "I'm not hiding anything, I just wanted privacy.",
      "Why do you need to know where I am all the time?",
    ],
    correctIndex: 1,
    explanation:
      "Demanding constant access to your location and using threats is a form of digital control and coercion.",
    riskScore: 84,
  },
  {
    id: 25,
    message:
      "I created a shared photo album for us. Now you have to upload every photo you take so I can see them too.",
    options: [
      "That sounds fun, I'll start uploading.",
      "I prefer keeping some photos private. I won't be doing that.",
      "Do I really have to upload everything?",
      "Maybe just the important ones?",
    ],
    correctIndex: 1,
    explanation:
      "Forcing you to share all content removes your autonomy and privacy over your own photos and memories.",
    riskScore: 69,
  },
  {
    id: 26,
    message: "Your Instagram story shows you're out with friends. I thought you said you were staying in tonight.",
    options: [
      "Plans changed last minute, sorry for not updating you.",
      "I don't need to report every change in my plans to you.",
      "I forgot to tell you, my bad.",
      "Why are you tracking my stories so closely?",
    ],
    correctIndex: 1,
    explanation:
      "Monitoring your social media to track your whereabouts and questioning discrepancies is controlling behavior.",
    riskScore: 64,
  },
  {
    id: 27,
    message:
      "I logged into your email because I was worried about you. I saw some messages I didn't like. We need to talk.",
    options: [
      "What messages? Let me explain.",
      "You violated my privacy. That's completely unacceptable.",
      "I understand you were worried, but that's not okay.",
      "How did you even get my password?",
    ],
    correctIndex: 1,
    explanation:
      "Accessing someone's accounts without permission is a serious violation and potentially illegal, regardless of intention.",
    riskScore: 91,
  },
  {
    id: 28,
    message: "I don't like the way you dress in your photos. Change your style or don't post pictures anymore.",
    options: [
      "I'll be more mindful of what I wear.",
      "How I dress is my choice. You don't get to control that.",
      "Why does it bother you so much?",
      "I'll just post less then.",
    ],
    correctIndex: 1,
    explanation:
      "Attempting to control your appearance or what you post is a form of controlling and manipulative behavior.",
    riskScore: 73,
  },
  {
    id: 29,
    message:
      "I went through your phone while you were asleep. I didn't find anything, but don't be mad—I needed to be sure.",
    options: [
      "I wish you had just asked me.",
      "That's a massive violation of trust. This is not okay.",
      "I have nothing to hide, but that still feels wrong.",
      "Did you really think you'd find something?",
    ],
    correctIndex: 1,
    explanation: "Going through someone's phone without permission is a severe breach of privacy and trust.",
    riskScore: 89,
  },
  {
    id: 30,
    message: "If you unfollow me or block me again, I'll make sure everyone sees the private messages you sent me.",
    options: [
      "Please don't do that. I won't unfollow you.",
      "That's blackmail and I'm reporting this immediately.",
      "Why are you threatening me?",
      "I don't want any trouble, so I'll keep you unblocked.",
    ],
    correctIndex: 1,
    explanation: "Threatening to expose private information is blackmail, a form of abuse, and potentially illegal.",
    riskScore: 96,
  },
]

export default function SimulatorPage() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [selectedOption, setSelectedOption] = useState<number | null>(null)
  const [showFeedback, setShowFeedback] = useState(false)
  const [safeChoices, setSafeChoices] = useState(0)
  const [completed, setCompleted] = useState(false)
  const [totalRisk, setTotalRisk] = useState(0)
  const [shuffledScenarios, setShuffledScenarios] = useState<Scenario[]>([])

  useEffect(() => {
    const shuffled = [...scenarios].sort(() => Math.random() - 0.5).slice(0, 30)
    setShuffledScenarios(shuffled)
  }, [])

  const currentScenario = shuffledScenarios[currentIndex]

  const handleOptionClick = (index: number) => {
    if (selectedOption !== null) return

    setSelectedOption(index)
    setShowFeedback(true)
    setTotalRisk((prev) => prev + currentScenario.riskScore)

    if (index === currentScenario.correctIndex) {
      setSafeChoices((prev) => prev + 1)
    }
  }

  const handleNext = () => {
    if (currentIndex < shuffledScenarios.length - 1) {
      setCurrentIndex((prev) => prev + 1)
      setSelectedOption(null)
      setShowFeedback(false)
    } else {
      setCompleted(true)
    }
  }

  const getRiskLevel = (score: number) => {
    if (score < 60) return { label: "Low Risk", color: "text-green-500" }
    if (score < 80) return { label: "Medium Risk", color: "text-yellow-500" }
    return { label: "High Risk", color: "text-red-500" }
  }

  if (shuffledScenarios.length === 0) {
    return (
      <div className="h-screen flex items-center justify-center">
        <GL hovering={false} />
        <p className="text-foreground relative z-10">Loading simulator...</p>
      </div>
    )
  }

  if (completed) {
    const avgRisk = Math.round(totalRisk / shuffledScenarios.length)
    const successRate = Math.round((safeChoices / shuffledScenarios.length) * 100)

    return (
      <div className="h-screen flex flex-col overflow-hidden">
        <GL hovering={false} />

        <div className="fixed z-50 pt-4 md:pt-6 lg:pt-8 top-0 left-0 w-full px-3 md:px-4">
          <div className="max-w-4xl mx-auto rounded-full backdrop-blur-md bg-white/10 dark:bg-black/10 border border-white/20 dark:border-white/10 px-4 md:px-6 py-3 md:py-4 flex items-center justify-between shadow-lg">
            <Link
              href="/"
              className="flex items-center gap-2 text-foreground hover:text-foreground/80 transition-colors"
            >
              <ArrowLeft className="w-4 h-4 md:w-5 md:h-5" />
              <span className="text-xl md:text-2xl font-sentient font-bold">GuardTFGBV</span>
            </Link>
            <span className="text-xs md:text-sm font-mono text-foreground/60">TFGBV Simulator</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto pt-24 md:pt-32 pb-6 md:pb-8 px-3 md:px-4 relative z-10 flex items-center justify-center">
          <div className="max-w-lg mx-auto w-full">
            <div className="backdrop-blur-md bg-white/10 dark:bg-black/10 border border-white/20 dark:border-white/10 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6 animate-fade-in">
              <h2 className="text-2xl md:text-3xl font-sentient text-foreground text-center">Simulation Complete</h2>

              <div className="space-y-4">
                <div className="bg-white/5 dark:bg-black/5 rounded-2xl p-4 border border-white/10">
                  <p className="text-sm text-foreground/60 mb-1">Scenarios Completed</p>
                  <p className="text-3xl font-sentient text-foreground">{shuffledScenarios.length}</p>
                </div>

                <div className="bg-white/5 dark:bg-black/5 rounded-2xl p-4 border border-white/10">
                  <p className="text-sm text-foreground/60 mb-1">Safe Choices Made</p>
                  <p className="text-3xl font-sentient text-primary">
                    {safeChoices} ({successRate}%)
                  </p>
                </div>

                <div className="bg-white/5 dark:bg-black/5 rounded-2xl p-4 border border-white/10">
                  <p className="text-sm text-foreground/60 mb-1">Average Risk Level Encountered</p>
                  <p className={`text-2xl font-sentient ${getRiskLevel(avgRisk).color}`}>
                    {getRiskLevel(avgRisk).label}
                  </p>
                </div>
              </div>

              <div className="bg-primary/10 border border-primary/20 rounded-2xl p-4">
                <p className="text-sm font-mono text-foreground leading-relaxed">
                  TFGBV often starts with subtle behaviors that seem harmless. Recognizing early warning signs like
                  digital surveillance, guilt-tripping, and boundary violations is crucial. Trust your instincts and
                  prioritize your digital safety and privacy.
                </p>
              </div>

              <div className="flex gap-3">
                <Button onClick={() => window.location.reload()} className="flex-1" size="lg">
                  Restart Simulator
                </Button>
                <Link href="/" className="flex-1">
                  <Button variant="outline" className="w-full bg-transparent" size="lg">
                    Return Home
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <GL hovering={false} />

      <div className="fixed z-50 pt-4 md:pt-6 lg:pt-8 top-0 left-0 w-full px-3 md:px-4">
        <div className="max-w-4xl mx-auto rounded-full backdrop-blur-md bg-white/10 dark:bg-black/10 border border-white/20 dark:border-white/10 px-4 md:px-6 py-3 md:py-4 flex items-center justify-between shadow-lg">
          <Link href="/" className="flex items-center gap-2 text-foreground hover:text-foreground/80 transition-colors">
            <ArrowLeft className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-xl md:text-2xl font-sentient font-bold">GuardTFGBV</span>
          </Link>
          <span className="text-xs md:text-sm font-mono text-foreground/60">
            Scenario {currentIndex + 1} of {shuffledScenarios.length}
          </span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pt-24 md:pt-32 pb-6 md:pb-8 px-3 md:px-4 relative z-10 flex items-center">
        <div className="max-w-lg mx-auto w-full space-y-4 md:space-y-6">
          <div className="text-center mb-6">
            <p className="text-sm md:text-base font-mono text-foreground/80 mb-2">
              Read the message and choose how you would respond
            </p>
          </div>

          <div className="flex justify-start animate-slide-in-left">
            <div className="max-w-[85%] sm:max-w-[80%] p-3 md:p-4 rounded-2xl bg-white/10 dark:bg-black/10 backdrop-blur-md border border-white/20 dark:border-white/10">
              <p className="text-xs sm:text-sm font-mono text-foreground">{currentScenario.message}</p>
            </div>
          </div>

          {selectedOption === null ? (
            <div className="space-y-3 animate-fade-in">
              <p className="text-xs md:text-sm font-mono text-foreground/60 text-center mb-2">Select your response:</p>
              {currentScenario.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleOptionClick(index)}
                  className="w-full text-left p-3 md:p-4 rounded-2xl bg-white/5 dark:bg-black/5 backdrop-blur-sm border border-white/10 hover:border-primary/50 hover:bg-white/10 dark:hover:bg-black/10 transition-all duration-200 hover:scale-[1.02]"
                >
                  <p className="text-xs sm:text-sm font-mono text-foreground">{option}</p>
                </button>
              ))}
            </div>
          ) : (
            <>
              <div className="flex justify-end animate-slide-in-right">
                <div className="max-w-[85%] sm:max-w-[80%]">
                  <div className="p-3 md:p-4 rounded-2xl bg-primary text-primary-foreground">
                    <p className="text-xs sm:text-sm font-mono">{currentScenario.options[selectedOption]}</p>
                  </div>
                </div>
              </div>

              {showFeedback && (
                <div className="space-y-4 animate-fade-in">
                  <div className="flex justify-start">
                    <div className="max-w-[85%] sm:max-w-[80%] p-3 md:p-4 rounded-2xl bg-white/10 dark:bg-black/10 backdrop-blur-md border border-white/20 dark:border-white/10">
                      <p className="text-xs sm:text-sm font-mono text-foreground mb-2">
                        {selectedOption === currentScenario.correctIndex ? "✓ Good response! " : "✗ Consider this: "}
                        {currentScenario.explanation}
                      </p>
                      {selectedOption !== currentScenario.correctIndex && (
                        <p className="text-xs font-mono text-primary/80 mt-2">
                          Better response: {currentScenario.options[currentScenario.correctIndex]}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <Button onClick={handleNext} size="lg" className="min-w-[200px] text-white">
                      {currentIndex < shuffledScenarios.length - 1 ? "Next Scenario" : "View Results"}
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
