export const API_CONFIG = {
  MAIL_SVC_ID: "your_emailjs_service_id_here",
  MAIL_TPL_ID: "your_emailjs_template_id_here",
  MAIL_PUB_KEY: "your_emailjs_public_key_here",
  ML_API_TOKEN: "your_groq_api_key_here",
}
