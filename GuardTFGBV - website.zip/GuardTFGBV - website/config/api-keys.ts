export const API_CONFIG = {
  MAIL_SVC_ID: "",
  MAIL_TPL_ID: "",
  MAIL_PUB_KEY: "",
  ML_API_TOKEN: "",
}
