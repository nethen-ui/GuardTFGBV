export const API_CONFIG = {
  MAIL_SVC_ID: "service_6quxfa8",
  MAIL_TPL_ID: "template_eqjangr",
  MAIL_PUB_KEY: "Y-3uTWwsVnkopIYro",
  ML_API_TOKEN: "",
}
