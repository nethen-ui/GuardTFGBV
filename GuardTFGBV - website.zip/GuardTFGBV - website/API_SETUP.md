# API Configuration Guide

This application requires API keys to function properly. Follow these steps to configure your keys securely.

## Setup Instructions

1. Copy the example configuration file:
   - Duplicate `config/api-keys.example.ts` 
   - Rename it to `config/api-keys.ts`

2. Add your API keys to `config/api-keys.ts`:

\`\`\`typescript
export const API_CONFIG = {
  MAIL_SVC_ID: "your_actual_service_id",
  MAIL_TPL_ID: "your_actual_template_id", 
  MAIL_PUB_KEY: "your_actual_public_key",
  ML_API_TOKEN: "your_actual_groq_api_key",
}
\`\`\`

## Getting API Keys

### EmailJS (For Report System)
1. Sign up at https://www.emailjs.com/
2. Create a service and get your Service ID
3. Create an email template and get your Template ID
4. Get your Public Key from account settings
5. Add these to MAIL_SVC_ID, MAIL_TPL_ID, and MAIL_PUB_KEY

### Groq (For Guard AI Chatbot)
1. Sign up at https://console.groq.com/
2. Generate an API key
3. Add it to ML_API_TOKEN

## Security Notes

- The `config/api-keys.ts` file is ignored by git and won't be committed
- API keys are only used server-side in API routes, never exposed to clients
- Never share your `api-keys.ts` file or commit it to version control
- When deploying, make sure to create the `api-keys.ts` file on your server

## Deployment

When hosting on any platform (Netlify, Railway, Render, etc.):
1. Upload all files except `config/api-keys.ts`
2. Manually create `config/api-keys.ts` on the server with your keys
3. Or use the platform's environment variables if supported
